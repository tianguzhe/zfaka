INSERT INTO `t_config` (`id`, `catid`, `name`, `value`, `tag`, `lock`, `updatetime`) VALUES (25, 1, 'limitorderqty', '5', '单笔订单数量限制', 1, 1453452674);
