INSERT INTO `t_config` (`id`, `catid`, `name`, `value`, `tag`, `lock`, `updatetime`) VALUES
(15, 1, 'm_prodcut_description', '0', '移动端商品详情，隐藏(0)|显示(1)', 1, 1453452674),
(16, 1, 'order_prefix', 'zlkb', '订单前缀，建议不要超过5个字符串', 1, 1453452674);
